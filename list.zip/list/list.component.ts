import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../employee';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';
import { StudentsService } from '../students.service';



@Component({
  selector: 'app-root',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent {
  
  
  constructor(private __studentsService:StudentsService,private router:Router,private http:HttpClient){}
  employees: any;
  title = 'crud';
  
  ngOnInit(){
    this.__studentsService.getStudents().subscribe(data => this.employees = data)
  }
  deleteItem(post){
    var r = confirm("Are you sure you want to Permanently delete employee with Id "+ post +" ?");
    if(r==true){
      // alert("hi!");
      // this.http.delete("https://localhost:44397/Employee/Delete/"+post); 
    this.__studentsService.deletePost(post)
        .subscribe(data => alert(data));
        //this.ngOnInit();
       window.location.href = "http://localhost:4200/list";
    }
  }
  EditItem(id){
    // this.router.navigate(['/edit/', { id: id }]);
    
       this.router.navigateByUrl(`/edit/${id}`).then(() => {
       window.location.reload();
     });
   
  }
  Addstu(){
    // this.router.navigate(['/edit/', { id: id }]);
    
    this.router.navigateByUrl(`add-student`) 
  }

  
}
