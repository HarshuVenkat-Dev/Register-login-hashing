import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  empFrom: FormGroup;
  id: string;
  isAddMode: boolean;
  loading = false;
  submitted = false;
  constructor(private formbuilder:FormBuilder,private studentservice:StudentsService,private route: ActivatedRoute) { }
  
  ngOnInit(): void {
   

    this.init();
    this.id = this.route.snapshot.params['id'];
    this.isAddMode = !this.id;
    if (!this.isAddMode) {
      // window.location.href = "http://localhost:4200/edit/"+this.id;
      this.studentservice.getStudentByid(this.id)
          .subscribe(x => this.empFrom.patchValue(x));
  }
  }
  get f() { return this.empFrom.controls; }
  public onsubmitted():void{
    // console.log(this.studFrom.get('stu_id').value)
    // var formData: any = new FormData();
    // formData.append("stu_id", this.studFrom.get('stu_id').value);
    // formData.append("stu_name", this.studFrom.get('stu_name').value);
    // formData.append("stu_age", this.studFrom.get('stu_age').value);
    // console.log(formData)
   
    if (this.isAddMode) {
      this.studentservice.AddStudent(this.empFrom).subscribe(data=>{alert(data);window.location.href = "http://localhost:4200/list"});
    // window.location.href = "http://localhost:4200/list";
  } else {
    
    this.studentservice.Update(this.empFrom,this.id).subscribe(data=>{alert(data);window.location.href = "http://localhost:4200/list"});
    // window.location.href = "http://localhost:4200/list";
  }
    
  }
  private init():void{
    this.empFrom=this.formbuilder.group({
      empId: [],
      empName: [],
      empCity: []
    })
  }
}


